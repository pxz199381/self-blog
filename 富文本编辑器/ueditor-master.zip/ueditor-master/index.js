var ueditor = require('./lib')
module.exports = ueditor;